package Bigbigdw.JoaraDW.Fragment_Main;

public class Main_More_ListData {
    String Contents;
    String StartDate;

    public Main_More_ListData(String Contents, String StartDate) {
        this.Contents = Contents;
        this.StartDate = StartDate;
    }
    public String getContents() {
        return Contents;
    }
    public String getStartDate() {
        return StartDate;
    }
}
